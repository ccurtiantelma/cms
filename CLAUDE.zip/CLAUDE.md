# CLAUDE.md — CMS

> Fonte canonica unica delle regole operative; i ruoli AI vivono in `.claude/agents/`.
> Vince su qualsiasi mirror (`.kilo/agents/`, `.github/agents/`), perde contro
> `docs/constitution.md`. Ultima revisione: 2026-08-13.

## Identità del progetto

**CMS** — Content Management System **headless**, ad alte prestazioni e sicuro, orientato
alla produzione e gestione di **Pagine**; non è un motore di blog. L'obiettivo è un **super
clone avanzato di WordPress/Elementor**: la Pagina è l'entità centrale, composta da blocchi
visuali, versionata, tradotta, ottimizzata per motori di ricerca e generativi, servita via
API a qualsiasi frontend.
**Stack**: NestJS 11 + Drizzle ORM + PostgreSQL + Redis + BullMQ · React 19 + Mantine v7.

I 7 pilastri funzionali (editor visivo a blocchi, SEO/GEO, moduli di contatto, multilingua,
dashboard, tema e risorse, chatbot) sono mappati su F01–F12 in `docs/roadmap.md`, con
sequenza e dipendenze; avanzamento e decisioni aperte in `docs/TODO.md`. Solo dashboard e
tema hanno una base presente: la feature fondativa da cui dipende tutto il resto è **F01 —
Gestione Pagine**.

**Base tecnica già presente, da non re-implementare**: autenticazione JWT (access + refresh
con rotation), RBAC a soglie, MFA TOTP, audit log, impersonificazione SuperAdmin, gestione
utenti, profilo, sessioni/dispositivi, notifiche persistenti + realtime, storage documenti,
export Excel/PDF, health check, scheduling, osservabilità, tour guidato, theme customizer.
La logica di dominio si costruisce **sopra** questa base.

## Lettura obbligatoria prima di qualsiasi intervento

`docs/constitution.md` → `docs/business-rules.md` → `docs/glossary.md` → `docs/roadmap.md` →
spec/feature rilevante. Contratti API: `docs/openapi.yaml`. Porte, moduli e servizi:
`docs/system-architecture.md`. Non scrivere codice prima di averli letti.

**Gerarchia delle decisioni (EAIDOS)**, il codice è l'unico territorio in cui l'AI opera
autonomamente: Constitution → Business Rules → Glossary → System Architecture → Non
Functional Requirements → RFC → ADR → Feature → Spec → Plan → Task → Code.

**Anti-hallucination**: se l'informazione non è nei file `docs/`, **fermati e chiedi**. Non
inventare endpoint, tabelle, DTO, tipi di blocco, business rules o comportamenti.

## Agenti

| Agente | Quando invocarlo | Confine |
|---|---|---|
| `orchestrator` | Feature nuova, ampia o poco specificata: audit strategico + piano operativo (max 8 task) | Non scrive codice, non usa il terminale |
| `backend-developer` | Endpoint, servizi, DTO, query Drizzle, coda BullMQ, cache, schema DB | Solo `app/backend/` |
| `frontend-developer` | Pagine admin, chrome dell'editor, componenti dei blocchi, service, store | Solo `app/frontend/` |
| `test-engineer` | Copertura di una feature, riproduzione di un bug, contract test Bruno | Solo test e `bruno/` — mai la logica applicativa |

Definizioni complete in `.claude/agents/`; per un task piccolo e già coperto da questo file
non serve delegare. Regole trasversali: leggono `docs/constitution.md` prima di operare ·
solo il task corrente, zero refactoring fuori scope · fra spec e constitution vince la
constitution · nessun `any` senza commento · file completi, zero placeholder · se mancano
informazioni critiche dichiarano l'assunzione e si fermano (**STOP**, non inventare).

## Le due superfici API — mai servite dallo stesso controller

| | Superficie amministrativa | Superficie pubblica |
|---|---|---|
| Prefisso | `api/v1/app/<modulo>` | `api/v1/public/<risorsa>` |
| Auth | JWT obbligatorio + RBAC a soglie | Anonima, nessuna autorizzazione |
| Operazioni | Lettura e scrittura, tutti gli stati | **Sola lettura**, solo `published` |
| Cache | Mai | Redis, invalidazione per evento |
| Stato | ✅ Attiva | 🔜 Prevista con F03 |

Convenzioni: prefix globale `api/v1` · `@Controller('app/<modulo>')` autenticato ·
`@Controller('public/<risorsa>')` escluso da `AuthMiddleware` · JWT middleware globale con
esclusi `api/v1/auth/*`, `api/v1/health`, `/metrics`, `api/v1/public/*` · paginazione
`?p= ?i= ?q= ?o= ?d=` → `Pagination<T>` · URL amministrative con `guid` 16 char hex, URL
pubbliche con `slug` (+ `locale`).

## Regole del modello di contenuto — vincolanti per ogni codice che tocca il dominio

1. **La Pagina è l'entità centrale.** Non esiste un tipo "post" privilegiato.
2. **Contenuto = albero di Blocchi in JSON** (`jsonb`), validato server-side contro il
   registro dei tipi di blocco. Mai HTML opaco persistito come contenuto strutturale.
3. **Ogni pubblicazione produce una Revisione immutabile.** Il rollback è la
   ripubblicazione di una revisione passata, non la riscrittura della storia.
4. **Bozza e pubblicato coesistono**: modificare una Pagina pubblicata non altera ciò che il
   pubblico vede finché non si ripubblica.
5. **Ogni Pagina appartiene a un `locale`**; le traduzioni sono righe autonome legate da un
   gruppo di traduzione, con slug, SEO e stato di pubblicazione propri.
6. **Lo slug è l'identificatore pubblico** (unico per locale + genitore).
7. **SEO e GEO sono parte del contratto della Pagina**, non un plugin aggiunto dopo.
8. **La cache pubblica si invalida per evento**, mai per TTL sperato.

> **GEO = Generative Engine Optimization** (visibilità presso i motori di risposta AI), non
> geolocalizzazione — assunzione A1, **confermata dall'umano il 2026-08-13**. Affianca la
> SEO tradizionale senza sostituirla: condividono lo stesso blocco di metadati sulla Pagina.

**Regola Mantine — confine UI ↔ contenuto.** Mantine v7 è **obbligatoria per l'interfaccia
amministrativa e per la chrome dell'editor** (layout, pannelli, toolbar, modali, form di
configurazione). I **componenti dei blocchi non importano Mantine**: usano esclusivamente
CSS Modules propri e markup semantico, perché il formato dei contenuti non va legato a una
libreria UI — il contenuto sopravvive al codice ed è reso anche da consumer esterni.

## Decisioni aperte — non costruirci sopra senza segnalarlo

- **Superficie HTML pubblica** — l'API NestJS non renderizza HTML, ma i crawler dei motori di
  risposta AI non eseguono JavaScript: senza HTML servito, F07 e F08 sono irrealizzabili.
  Serve una ADR che scelga natura e collocazione del **consumer separato** della superficie
  `public/` (SSR, SSG o prerender). **Bloccante per F03, F07, F08**: non improvvisare né
  rendering nell'API né una soluzione client-only.
- **Ownership per riga dei permessi editoriali** (nota sotto la tabella RBAC) — **bloccante
  per F01**.
- **Assunzioni A2–A6** (`docs/business-rules.md`; dettaglio in `docs/TODO.md` → "Decisioni
  aperte") da confermare. La più critica è A5 (mono-sito vs multi-sito).

## Always do

- JSDoc su ogni funzione pubblica
- Frontend: ogni chiamata API in `try/catch` con `notifications.show` in caso di errore
- Endpoint nuovo o modificato → file Bruno `.yml` + `openapi:export` e `openapi:types`
- Sanitizza il rich text **server-side prima della persistenza**, sempre
- `Utils.applyScopeFilter(authInfo)` su ogni query che diventasse multi-tenant
- Commit Conventional; branch `main` (prod) · `develop` (staging) · `feature/<nome>`

## Ask first — approvazione umana obbligatoria

L'AI non decide da sola e non si auto-approva nulla (RFC, ADR, spec, plan):
- Qualsiasi file in `docs/` e le business rules (una ADR approvata non si tocca mai: si
  supera con una nuova ADR che marca la precedente `Superseded da ADR-XXX`)
- Schema del database (`app/backend/src/db/schema.ts`) e migrazioni conseguenti
- Installazione o aggiornamento di dipendenze npm
- Rinomina del pacchetto o di moduli (`package.json` → `name`, workspaces, CI/CD)
- Refactoring globali o di moduli fuori dal task corrente
- Nuovo tipo di blocco, o modifica dello schema di un blocco esistente (+ migrazione dei
  contenuti già salvati)
- Provider esterni (LLM per il chatbot, captcha, CDN)
- Qualsiasi decisione non coperta dalla documentazione esistente

## Divieti assoluti (tolleranza zero)

- `any` senza commento · `console.log` in produzione · `process.env` invece di `AppConstants`
- Secret, API key o file `.env` committati · inventare endpoint, tabelle, DTO, tipi di
  blocco o business rules non documentate
- Codice applicativo (logica, moduli, componenti, DTO) fuori da `app/` o `bruno/`. I file di
  configurazione/tooling di repository (`package.json`, `docker-compose.yml`,
  `.github/workflows/`, `.mcp.json`, `.env.example`) restano in root: non contengono logica
  di dominio e non possono vivere altrove
- `DELETE` fisico su entità anagrafiche o di contenuto (soft delete obbligatorio) ·
  `drizzle-kit push` in produzione
- `id` numerico sequenziale in URL — `guid` (admin) o `slug` (contenuto pubblico)
- Modificare file in `docs/` o componenti fuori dallo scope del task corrente
- Librerie UI diverse da Mantine v7 nell'interfaccia amministrativa; Mantine dentro i
  componenti dei blocchi (vedi "Regola Mantine")
- Persistere HTML non sanitizzato proveniente dall'editor
- **Renderizzare HTML di pagina nell'API NestJS**: l'API restituisce dati (albero di blocchi
  + metadati SEO/GEO). La superficie HTML pubblica è responsabilità di un consumer separato
  della superficie `public/`, la cui natura è oggetto di ADR (vedi "Decisioni aperte")
- Esporre contenuto non pubblicato su un endpoint `public/` · eseguire codice o template
  forniti dall'utente (no `eval`, no plugin dinamici)
- Inviare email da un service (sempre la coda BullMQ) · sovrascrivere silenziosamente il
  lavoro di un altro editor (sempre `409`)
- Scorciatoie temporanee senza ADR motivato e approvazione umana

## Convenzioni database

Schema unico in `app/backend/src/db/schema.ts` (ogni modifica → approvazione umana). FK
sempre `{ onDelete: 'restrict', onUpdate: 'restrict' }`, `relations(...)` dopo ogni tabella,
migrazioni con `drizzle-kit generate` → `drizzle-kit migrate`, contenuto strutturato in
`jsonb`, indici sulle colonne di risoluzione pubblica (`slug`, `locale`, `status`) e su ogni FK.

```
id          serial PRIMARY KEY
guid        char(16)                    ← usato nelle URL amministrative
version     integer NOT NULL DEFAULT 1  ← lock ottimistico: WHERE version = :version
isActive    boolean DEFAULT true        ← soft delete
createdAt   timestamp
updatedAt   timestamp
createdBy   integer FK → users.id  { onDelete: 'restrict', onUpdate: 'restrict' }
updatedBy   integer FK → users.id  { onDelete: 'restrict', onUpdate: 'restrict' }
```

`version` si incrementa a ogni update ed è la colonna su cui poggia il controllo ottimistico
di concorrenza (zero righe aggiornate ⇒ `409`); allinearvi le tabelle esistenti richiede una
migrazione, quindi approvazione umana. **Entità presenti**: `users`, `audit_log`,
`app_settings`, `files`, `notifications`. **Previste dal dominio** (nessuna implementata,
tutte da approvare): `pages`, `page_revisions`, `redirects`, `menus`, `forms`,
`form_submissions`.

## Ruoli RBAC e permessi editoriali

Nessun ruolo nuovo: si riusano le 4 soglie esistenti (numero minore = privilegio maggiore).

| Ruolo | Valore | Profilo editoriale |
|---|---|---|
| SuperAdmin | 5 | Tutto, incluso il blocco HTML/embed e la configurazione di sistema |
| Admin | 10 | Contenuti, utenti, impostazioni del sito, lingue, tema, redirect |
| Manager | 20 | Profilo editoriale con potere di pubblicazione |
| User | 30 | Autore: scrive e modifica **le proprie** bozze ⚠️, non pubblica |

> ⚠️ **"le proprie bozze" non è una soglia di ruolo**: è autorizzazione **per riga**
> (ownership sul record), e le guard esistenti (`GuardSuperAdmin`, `GuardAdmin`,
> `GuardManager`) sanno solo confrontare un livello. Serve un controllo di ownership
> esplicito nel service (`createdBy = authInfo.userId` combinato con lo stato della riga), da
> fissare in una ADR **prima** di implementare i permessi editoriali. L'assunzione A4
> ("bastano le 4 soglie esistenti") è corretta sui *ruoli* e sbagliata sui *permessi*:
> nessun ruolo nuovo, ma un meccanismo di autorizzazione in più.

Matrice completa: `docs/business-rules.md` → "Permessi editoriali".

## Security Policy — Security by Design

**Baseline**: JWT middleware globale (access 15min, refresh 7gg in cookie httpOnly firmato,
rotation ad ogni refresh), rate limiting su `/auth/*` (`@nestjs/throttler`), RBAC a soglie su
ogni endpoint sensibile più ownership per riga dove serve, class-validator su tutti i DTO con
`forbidNonWhitelisted: true`, password bcrypt cost 12 via `Utils.hashPassword`/
`Utils.verifyPassword`, Winston con accessi non autorizzati a `warn` e redazione automatica
di password/token/secret/email/phone (`sanitizeLogData`), audit trail `createdBy`/`updatedBy`
+ `AuditLogService`, Helmet in produzione, stack trace mai esposto in risposta.

Un CMS accetta contenuto ricco da utenti fidati e lo serve ad anonimi: è la definizione
stessa di superficie XSS. Perciò:

- **Sanitizzazione HTML server-side, sempre, prima della persistenza**, contro allowlist di
  tag e attributi
- **Nessun blocco può iniettare** `<script>`, `<iframe>` non allowlistato, handler `on*` o
  URL `javascript:`. Il blocco HTML/embed è riservato al SuperAdmin, tracciato in audit log
  e disabilitato finché una ADR dedicata non ne definisce i confini
- **Nessuna esecuzione di codice fornito dall'utente**: niente espressioni valutate a
  runtime, `eval` o plugin dinamici — il "clone di WordPress" **non** eredita il modello di
  plugin PHP arbitrario
- **Upload media**: MIME verificato dal contenuto reale e non dall'estensione, dimensione
  massima applicata, file serviti senza mai eseguirli, SVG trattato come contenuto attivo
- **Endpoint pubblici**: rate limiting proprio, nessuna informazione sui contenuti non
  pubblicati, `404` invece di `403`
- **Moduli di contatto**: anti-spam obbligatorio (rate limit per IP + honeypot + marca
  temporale), validazione server-side integrale, email solo via coda BullMQ, destinatari
  **mai** controllabili dal client (nessun mail relay aperto)
- **Chatbot**: prompt di sistema e chiavi del provider solo lato server, conoscenza limitata
  alle pagine pubblicate, ogni input utente non fidato (prompt injection)
- **Dati personali**: gli Invii dei moduli mai loggati per intero, nemmeno a `debug`; il
  loro export è tracciato in audit log

## Error Handling Policy

**Backend**: `AllExceptionsFilter` globale (`@Catch()`) in `main.ts` normalizza OGNI errore
in `{ statusCode, message, code, timestamp, path }`; la validazione dell'albero blocchi
risponde `400` con l'elenco dei path non validi — l'editor deve poter evidenziare il blocco
colpevole. **Frontend**: Error Boundary globale in `App.tsx` e **per singolo blocco** nel
renderer, con interceptor Axios differenziato per fascia di status
con `409` sempre esplicito e mai sovrascrittura silenziosa. Dettaglio nei rispettivi agent.

## Architecture, Documentation, Long Term Maintainability

Ogni decisione architetturale significativa richiede un **ADR**, nessuna eccezione (auth,
ORM, eventi, websocket, caching, auditing, integrazioni esterne, cambi di pattern). Per
questo CMS lo innescano anche: schema dei blocchi e suo versionamento, strategia di
revisioni, caching e invalidazione del contenuto pubblico, modello multilingua, routing e
risoluzione degli slug, pipeline media, provider del chatbot, sitemap e structured data,
consumer HTML della superficie `public/`, ownership per riga dei permessi editoriali. Una
ADR approvata non si modifica: si supera con una nuova che marca la precedente `Superseded
da ADR-XXX`.

La documentazione è codice: ogni modifica significativa aggiorna spec correlate, contratti
API (`openapi:export`), progress-tracker, roadmap. Tabella "chi scrive dove" in
`docs/constitution.md` → "Documentation Policy". **Il contenuto sopravvive al codice**: lo
schema dei blocchi va versionato e nessun breaking change è ammesso senza una strategia di
migrazione dei contenuti già salvati.
